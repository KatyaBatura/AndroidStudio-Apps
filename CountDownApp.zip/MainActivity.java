package katyabatuta.scrollingtext.countdownapp;

import android.os.CountDownTimer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final long Start_Time = 30000;
    private Button mButtonUp;
    private Button mButtonDown;
    private TextView mTextViewCountDown;
    private Button mButtonStart;
    private Button mButtonStop;
    private Button mButtonReset;
    private CountDownTimer mCountDownTimer;
    private boolean mTimerRunning;
    private long mTimeLeft = Start_Time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mButtonUp = findViewById(R.id.button_up);
        mButtonDown = findViewById(R.id.button_down);
        mTextViewCountDown = findViewById(R.id.text_view_countdown);
        mButtonStart = findViewById(R.id.button_start);
        mButtonStop = findViewById(R.id.button_stop);
        mButtonReset = findViewById(R.id.button_reset);

        mButtonUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateTimerUp();
            }
        });

        mButtonDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateTimerDown();
            }
        });

        mButtonStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTimer();
            }
        });

        mButtonStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopTimer();
            }
        });

        mButtonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();
            }
        });
        updateCountDownText();
    }

    private void startTimer() {
        mCountDownTimer = new CountDownTimer(mTimeLeft, 1000) {
            @Override
            public void onTick(long TimeUntilEnd) {
                mTimeLeft = TimeUntilEnd;
                mButtonStop.setVisibility(View.VISIBLE);
                updateCountDownText();
            }

            @Override
            public void onFinish() {
                mTimerRunning = false;
                mButtonStart.setVisibility(View.INVISIBLE);
                mButtonReset.setVisibility(View.VISIBLE);
            }
        }.start();
        mTimerRunning = true;
        mButtonStop.setVisibility(View.VISIBLE);
        mButtonUp.setVisibility(View.INVISIBLE);
        mButtonDown.setVisibility(View.INVISIBLE);
        mButtonStart.setVisibility(View.INVISIBLE);
        mButtonReset.setVisibility(View.INVISIBLE);
    }

    private void stopTimer() {
        mCountDownTimer.cancel();
        mTimerRunning = false;
        mButtonStart.setVisibility(View.VISIBLE);
        mButtonReset.setVisibility(View.VISIBLE);
        mButtonStop.setVisibility(View.INVISIBLE);
        mButtonUp.setVisibility(View.INVISIBLE);
        mButtonDown.setVisibility(View.INVISIBLE);
    }

    private void resetTimer() {
        mTimeLeft = Start_Time;
        updateCountDownText();
        mButtonUp.setVisibility(View.VISIBLE);
        mButtonDown.setVisibility(View.VISIBLE);
        mButtonStart.setVisibility(View.VISIBLE);
        mButtonStop.setVisibility(View.VISIBLE);
        mButtonReset.setVisibility(View.VISIBLE);
    }

    private void updateTimerUp() {
        if (mTimeLeft < 90000) {
            mTimeLeft = mTimeLeft + 1000;
            updateCountDownText();
        }
    }

    private void updateTimerDown() {
        if (mTimeLeft > 5000) {
            mTimeLeft = mTimeLeft - 1000;
            updateCountDownText();
        }
    }

    private void updateCountDownText() {
        int minutes = (int) (mTimeLeft / 1000) / 60;
        int seconds = (int) (mTimeLeft / 1000) % 60;
        String timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
        mTextViewCountDown.setText(timeLeftFormatted);
    }
}